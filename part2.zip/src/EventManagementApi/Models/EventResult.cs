namespace EventManagementApi.Models;

public class EventResult
{
    public int Id { get; set; }
    public int EnrolmentId { get; set; }
    public EventEnrolment? Enrolment { get; set; }
    public TimeSpan FinishTime { get; set; }
    public int FinishPosition { get; set; }
    public DateTime RecordedAt { get; set; } = DateTime.UtcNow;
}
