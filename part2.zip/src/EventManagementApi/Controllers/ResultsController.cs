using EventManagementApi.Data;
using EventManagementApi.Models;
using EventManagementApi.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EventManagementApi.Controllers;

[ApiController, Route("api/results")]
public class ResultsController(AppDbContext db, CurrentUserService current) : ControllerBase
{
    public record ResultRequest(TimeSpan FinishTime, int FinishPosition);

    /// <summary>Record a result for an enrolment in an event owned by the organiser.</summary>
    [HttpPost("enrolment/{enrolmentId:int}")]
    public async Task<IActionResult> Record(int enrolmentId, ResultRequest request)
    {
        if (current.Role != UserRole.Organiser) return current.IsAuthenticated ? Forbid() : Unauthorized();
        if (request.FinishTime <= TimeSpan.Zero || request.FinishPosition <= 0)
            return BadRequest(new { message = "Finish time and position must be positive." });
        var enrolment = await db.Enrolments.Include(x => x.Event).FirstOrDefaultAsync(x => x.Id == enrolmentId);
        if (enrolment is null) return NotFound();
        if (enrolment.Event?.OrganiserId != current.UserId) return Forbid();
        if (await db.Results.AnyAsync(x => x.EnrolmentId == enrolmentId)) return Conflict(new { message = "Result already exists." });
        var result = new EventResult { EnrolmentId = enrolmentId, FinishTime = request.FinishTime, FinishPosition = request.FinishPosition };
        db.Results.Add(result); await db.SaveChangesAsync();
        return Created($"/api/results/mine", result);
    }

    /// <summary>Participant views their own results only.</summary>
    [HttpGet("mine")]
    public async Task<IActionResult> Mine()
    {
        if (current.Role != UserRole.Participant) return current.IsAuthenticated ? Forbid() : Unauthorized();
        return Ok(await db.Results.Include(x => x.Enrolment).ThenInclude(x => x!.Event)
            .Where(x => x.Enrolment!.ParticipantId == current.UserId)
            .Select(x => new { x.Id, EventId = x.Enrolment!.EventId, EventName = x.Enrolment.Event!.Name,
                x.FinishTime, x.FinishPosition, x.RecordedAt }).ToListAsync());
    }
}
