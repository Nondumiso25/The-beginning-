# Event Management API (ASP.NET Core 8 + SQL Server)

Starter implementation based on the supplied PROG6212 POE requirements:
- SQL Server + EF Core code-first models for users, events, categories, enrolments and results.
- Session-based login/logout, role-aware endpoints and PBKDF2 password hashing.
- Organiser-owned event/category management and result recording.
- Participant enrolment and own-result viewing.
- Swagger UI and GitHub Actions build/test workflow.
- Unit tests for password hashing.

## Requirements
- .NET 8 SDK
- Visual Studio 2022 (ASP.NET and web development workload)
- SQL Server LocalDB (or change the connection string to your SQL Server instance)

## Run
1. Open `EventManagementApi.sln` in Visual Studio.
2. Update `src/EventManagementApi/appsettings.json` -> `ConnectionStrings:DefaultConnection` for your SQL Server.
3. Run the `EventManagementApi` project.
4. Open `/swagger` in the browser. In Development, Swagger UI is enabled.
5. Register users via `POST /api/auth/register`, then login via `POST /api/auth/login`. Login stores a session cookie; Swagger requests must retain/send that cookie. If your Swagger/browser setup does not retain cookies, use a REST client or configure Swagger UI to send cookies.

## Important security / coursework notes
- For a real deployment, do not allow arbitrary public users to register as Organiser. Add an administrator/invitation workflow.
- Session cookies require HTTPS in deployment. Configure cookie SameSite and secure settings to suit your hosting environment.
- `EnsureCreated()` is used to make first run simple for coursework. For a maintained project, replace it with EF Core migrations (`dotnet ef migrations add InitialCreate`, then `dotnet ef database update`).
- The provided tests are a starting point. Expand integration tests for unauthenticated access, participant/organiser role rejection, event CRUD ownership, category validation, enrolment recording, and result privacy before submission.
- Align field names and relationships with your Part 1 approved ERD and SQL script; those documents were not included in the images supplied here.

## Main endpoints
| Method | Endpoint | Access / purpose |
|---|---|---|
| POST | `/api/auth/register` | Register user |
| POST | `/api/auth/login` | Login and establish session |
| POST | `/api/auth/logout` | Clear session |
| GET/PUT | `/api/users/me` | View/update own profile |
| GET | `/api/events` | List events |
| GET | `/api/events/{id}` | Event detail |
| POST | `/api/events` | Organiser creates event |
| PUT/DELETE | `/api/events/{id}` | Owning organiser updates/deletes event |
| GET | `/api/events/{eventId}/categories` | List categories |
| POST | `/api/events/{eventId}/categories` | Owning organiser adds category |
| DELETE | `/api/events/{eventId}/categories/{categoryId}` | Owning organiser deletes category |
| POST | `/api/enrolments` | Participant enrols in category |
| GET | `/api/enrolments/mine` | Participant sees own enrolments |
| GET | `/api/enrolments/event/{eventId}` | Owning organiser sees event enrolments |
| POST | `/api/results/enrolment/{enrolmentId}` | Owning organiser records finish time/position |
| GET | `/api/results/mine` | Participant sees own results |

## Run tests
```bash
dotnet test EventManagementApi.sln
```

This is a coursework starter, not a claim that it has been built against your Part 1 schema. Verify it in Visual Studio and adjust the schema/endpoints to your approved plan.
